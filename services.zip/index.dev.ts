import "module-alias/register";

import "./src/index";