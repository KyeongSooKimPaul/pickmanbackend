import "dotenv/config";

import "#root/db/connection";
import "#root/server/startServer";