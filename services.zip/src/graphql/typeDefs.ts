import { gql } from "apollo-server";

const typeDefs = gql`

  type User {
    id : ID!
    email : String!
    roll : String!
    password :  String!
    rawexcels : [Rawexcel!]!
  }

  type Chef {
    id: ID!
    name: String!
    restaurants: [Restaurant!]!
  }

  type Restaurant {
    id: ID!
    name: String!
  }

  type Rawexcel {
    id : ID!
    date : String!
    name: String!
    address: String!
    phone: String!
    code: String!
    color: String!
    size: String!
    price: String!
    amount: String!
    total: String!
    roll : String!
    email : String!
  }

  type Mutation {
 
    loginUser(email: String!, password: String!): User!
    createUser(email: String!, password: String!, roll: String! ): User!
    createChef(name: String!): Chef!
    createRestaurant(chefId: ID!, name: String!): Restaurant!
    createRawexcel(userId: ID!,date: String!, name: String!, address:String!, phone: String!, 
      code: String!, color:String!, size: String!,
     price: String!, amount:String!, total: String!, roll: String!, email: String! 
): Rawexcel!
  }

  type Query {
    chefs: [Chef!]!
    users: [User!]!
    usersbyId(id : ID!): [User!]!
    usersbyRoll(roll : String!): [User!]!
  }
`;



export default typeDefs;