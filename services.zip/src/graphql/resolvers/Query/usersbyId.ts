import { User } from "#root/db/models";

const usersbyIdResolver = (context: any, { id} : {id: string}) => {
  return User.findAll({where: {id : id}});
  // return User.findAll({});
};

export default usersbyIdResolver;
