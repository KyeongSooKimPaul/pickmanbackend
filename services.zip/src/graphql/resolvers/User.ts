import { User, Rawexcel} from "#root/db/models";

const resolvers = {
  rawexcels: (user: User) => {
    return Rawexcel.findAll({
      include: [
        {
          model: User,
          where: { id: user.id }
        }
      ],
      order: [["id", "ASC"]]
    });
  }
};

export default resolvers;